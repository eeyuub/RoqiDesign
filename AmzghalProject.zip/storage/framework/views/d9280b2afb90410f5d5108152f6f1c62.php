<p
    class="fi-section-header-description text-sm text-gray-500 dark:text-gray-400"
>
    <?php echo e($slot); ?>

</p>
<?php /**PATH C:\Users\EYUB\Desktop\AmzghalProject\vendor\filament\support\src\/../resources/views/components/section/description.blade.php ENDPATH**/ ?>